﻿-----------------------
# README
-----------------------


TourNest is an extraordinary HTML5 responsive website template for Tours. Our UX designers specially designed it for travel agencies, tourism bureaus and tour operators. It offers a lot of value to you with stunning design and the great & awesome layout. It’s really good looking with bright colors and user engaging with a great user interface.
TourNest has a special search box function for tour plans, flight booking, and hotel sections. So users will get benefit from tour planning to hotel booking through flight selection.


Template Info:
-----------------------
Name: 		TourNest - Free Bootstrap HTML5 Template
Version: 	1.0
Author: 	ThemeSINE
Website: 	https://www.themesine.com/


Changelog:
-----------------------
Version 1.0 10-02-2018
- initial release

License:
-----------------------
Copyright (c) 2018 ThemeSINE

TourNest is licensed under The MIT License (MIT). Which means that you can use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the final products. But you always need to state that ThemeSINE is the original author of this template.
